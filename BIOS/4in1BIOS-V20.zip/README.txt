The 4in1 uses a 39SF010 Flash ROM, which cannot be written with the XTIDECFG application.

You must use the XT-CF ROM Flashing application by James Pierce, using the following command:

FLASH !3in1-ide.bin C000

If you are using the V20 version of the bios, replace the filename with !3in1-v20.bin.